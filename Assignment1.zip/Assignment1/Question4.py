#Given data
it_companies = set(['Facebook', 'Google', 'Microsoft', 'Apple', 'IBM', 'Oracle', 'Amazon'])
A = {19, 22, 24, 20, 25, 26}
B = {19, 22, 20, 25, 26, 24, 28, 27}
age = [22, 19, 24, 25, 26, 24, 25, 24]


# Length of set of it_companies
print("Length of set of it_companies: ", len(it_companies))

# Add 'Twitter' to it_companies
it_companies.add('Twitter')
print(it_companies)

# Add multiple elements to it_companies
it_companies.update(['Infosys', 'TCS'])
print(it_companies)

# Remove one element from it_companies
it_companies.remove('TCS')
print(it_companies)

# Difference between remove() and discard()
# remove() and discard() methods are used to remove element from the set
# only difference is remove() will raise error if element is not present in the set
# while discard() won't raise error

# Join A and B
print('A Join B : ', A.union(B))

# A intersection B
print('A intersection B:', A.intersection(B))

# A subset of B
print('A subset of B:', A.issubset(B))

# disjoints A and B
print('A disjoint set B:', A.isdisjoint(B))
print('B disjoint set A:', B.isdisjoint(A))

# # A join B and B join A
A.update(B)
print('A join B:', A)
B.update(A)
print('B join A:', B)

# Symmetric difference
print('A symmetric difference B:', A.symmetric_difference(B))

# Delete Sets
del A
del B

# age list and set
age_set=set(age)
print("Len of age list:", len(age))
print("Len of age set:",len(age_set))
print(len(age)==len(age_set))