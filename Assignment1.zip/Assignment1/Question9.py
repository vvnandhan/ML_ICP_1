N = int(input("Enter no.of students:"))  # input from user

# input weights requested in comma separation format and assigned in a list
ip_list = [int(N) for N in input("Enter {0} weights with comma separation: ".format(N)).split(",")]

print("Input List: ", ip_list)

result = []
for i in ip_list:
    result.append(round(i / 2.205, 2))  # converting weights from lbs to kgs and adding to result list

print("Output : ", result)