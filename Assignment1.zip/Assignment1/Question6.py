ip_str = "I am a teacher and I love to inspire and teach people"

str_list   = ip_str.split(' ') # assigned all the individual words to a list using split function
uniq_words = set(str_list) # converted the list to set
print("Unique Words: ", uniq_words)
print(len(uniq_words))