print("Name \t Age\tCountry\tCity")
print("Asabeneh  250 \tFinland\tHelsinki")