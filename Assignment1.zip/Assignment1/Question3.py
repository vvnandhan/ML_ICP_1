#Two tuples of sisters and brothers data
sisters  = ('Tiyasha', 'Kushboo',)
brothers = ('Raghu', 'Virat', 'Arjit',)

# Join brothers and sisters tuples
siblings = brothers + sisters
print("Siblings : ",siblings)

# No.of siblings
print("Number Of Siblings:", len(siblings))

#CASE 1: adding new tuple with parents details
father = 'Yuvraj'
mother = 'Ashi'

parents = (father, mother,) #Assigned father & mother names to a new tuple

family_members = parents+siblings # Added parents tuple with siblings tuple and assigned it to family members tuple

print("Family Members Details in CASE 1:",family_members)

#CASE 2: Coverting siblings tuple to list and adding parents details
temp_siblings=list(siblings) # Converted siblings tuple to list and assigned to temporary variable

temp_siblings.extend(["Yuvraj","Ashi"]) # Added father and mother names to temporary variable

family_members_updated=tuple(temp_siblings) # coverted the temp variable to tuple and assigned to family members

print("Family Members Details in CASE 2:",family_members_updated)