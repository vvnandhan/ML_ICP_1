dog = dict()  # An Empty dictionary dog

# Adding dog's name, color, breed, legs, age
dog['name'] = 'Puppy'
dog['color'] = 'white'
dog['breed'] = 'Dalmatian'
dog['legs'] = 4
dog['age'] = 10

print(dog)

# Student dictionary
student = dict({
    'first_name': 'Pavan',
    'last_name': 'Kalyan',
    'gender': 'Male',
    'age': 24,
    'marital_status': 'unmarried',
    'skills': ['python', 'java'],
    'country': 'India',
    'city': 'Nuzvid'
})

print(student)

# Len of student
print("Student length:", len(student))

# Get value of skills
print("Skills:", student.get('skills'))

# Add new skill
skills = student.get('skills')
skills.append('C#')
student['skills'] = skills

print("Updated Skills:", student.get('skills'))

# Get keys
print("Dictionary Keys:", list(student.keys()))

# Get Values
print("Dictionary Values:", list(student.values()))