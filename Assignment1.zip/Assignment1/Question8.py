radius = 10 #assigned radius value
area   = 3.14 * (radius**2) # calculated the area

#printing the required format using string format method
print("radius = {0}".format(radius))
print("area = {0} * radius **2 ".format(area))
print("The area of a circle with radius {0} is {1} meters square.".format(radius,area))