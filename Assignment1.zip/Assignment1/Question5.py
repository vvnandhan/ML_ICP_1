import math

radius = 30

# Area of Circle
_area_of_circle_ = math.pi * radius**2
print(_area_of_circle_)

# Circumference of circle
_circum_of_circle_ = 2 * math.pi * radius
print(_circum_of_circle_)

ip_radius = float(input("Please enter radius of circle:"))
_area_of_circle_ = math.pi * ip_radius**2
print(_area_of_circle_)