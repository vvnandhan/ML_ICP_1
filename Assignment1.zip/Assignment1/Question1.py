# List of 10 students ages
ages = [19, 22, 19, 24, 20, 25, 26, 24, 25, 24]

# Sorting the list
ages.sort()

# Min and Max age of the sudents ages list
min_age, max_age = min(ages), max(ages)

print("Min Age:", min_age)
print("Max Age:", max_age)

ages.insert(0,  min_age) # Insert min age at beginning

ages.insert(-1, max_age) # Insert max age at end

print("Ages list after inserting values:", ages)

# Caluculating median age
ages_list_len = len(ages)
mid_value  = ages_list_len//2

if ages_list_len%2==0:
    median_age = (ages[mid_value] + ages[mid_value+1])/2
else:
    median_age = ages[mid_value]

print("Median Age:", median_age)

# Average Age
print("Average Age:",sum(ages)/ages_list_len)

# Range of Ages max - min
print(f"Range of ages :", max_age - min_age) 